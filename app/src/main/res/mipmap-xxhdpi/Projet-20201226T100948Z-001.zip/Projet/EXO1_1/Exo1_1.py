#!/usr/bin/env python2
# -*- coding: utf-8 -*-
##################################################
# GNU Radio Python Flow Graph
# Title: Top Block
# Generated: Tue Nov 26 09:58:51 2019
##################################################


if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x11 = ctypes.cdll.LoadLibrary('libX11.so')
            x11.XInitThreads()
        except:
            print "Warning: failed to XInitThreads()"

from gnuradio import analog
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio import gr
from gnuradio import wxgui
from gnuradio.eng_option import eng_option
from gnuradio.fft import window
from gnuradio.filter import firdes
from gnuradio.wxgui import fftsink2
from gnuradio.wxgui import forms
from grc_gnuradio import wxgui as grc_wxgui
from optparse import OptionParser
import wx


class top_block(grc_wxgui.top_block_gui):

    def __init__(self):
        grc_wxgui.top_block_gui.__init__(self, title="Top Block")
        _icon_path = "/usr/share/icons/hicolor/32x32/apps/gnuradio-grc.png"
        self.SetIcon(wx.Icon(_icon_path, wx.BITMAP_TYPE_ANY))

        ##################################################
        # Variables
        ##################################################
        self.samp_rate_0 = samp_rate_0 = 2e5
        self.f = f = 5e3
        self.b = b = 1e3

        ##################################################
        # Blocks
        ##################################################
        self.wxgui_fftsink2_0 = fftsink2.fft_sink_c(
        	self.GetWin(),
        	baseband_freq=0,
        	y_per_div=10,
        	y_divs=10,
        	ref_level=0,
        	ref_scale=2.0,
        	sample_rate=samp_rate_0,
        	fft_size=1024,
        	fft_rate=15,
        	average=False,
        	avg_alpha=None,
        	title='FFT Plot',
        	peak_hold=False,
        	win=window.flattop,
        )
        self.Add(self.wxgui_fftsink2_0.win)
        _f_sizer = wx.BoxSizer(wx.VERTICAL)
        self._f_text_box = forms.text_box(
        	parent=self.GetWin(),
        	sizer=_f_sizer,
        	value=self.f,
        	callback=self.set_f,
        	label='f',
        	converter=forms.int_converter(),
        	proportion=0,
        )
        self._f_slider = forms.slider(
        	parent=self.GetWin(),
        	sizer=_f_sizer,
        	value=self.f,
        	callback=self.set_f,
        	minimum=0,
        	maximum=1e4,
        	num_steps=100,
        	style=wx.SL_HORIZONTAL,
        	cast=int,
        	proportion=1,
        )
        self.Add(_f_sizer)
        self.blocks_throttle_0 = blocks.throttle(gr.sizeof_gr_complex*1, samp_rate_0,True)
        self.band_pass_filter_0 = filter.fir_filter_ccf(1, firdes.band_pass(
        	1, samp_rate_0, 4e3, 6e3, 2e2, firdes.WIN_HAMMING, 6.76))
        _b_sizer = wx.BoxSizer(wx.VERTICAL)
        self._b_text_box = forms.text_box(
        	parent=self.GetWin(),
        	sizer=_b_sizer,
        	value=self.b,
        	callback=self.set_b,
        	label='b',
        	converter=forms.int_converter(),
        	proportion=0,
        )
        self._b_slider = forms.slider(
        	parent=self.GetWin(),
        	sizer=_b_sizer,
        	value=self.b,
        	callback=self.set_b,
        	minimum=0,
        	maximum=1e4,
        	num_steps=100,
        	style=wx.SL_HORIZONTAL,
        	cast=int,
        	proportion=1,
        )
        self.Add(_b_sizer)
        self.analog_noise_source_x_0 = analog.noise_source_c(analog.GR_GAUSSIAN, 1, 0)



        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_noise_source_x_0, 0), (self.blocks_throttle_0, 0))
        self.connect((self.band_pass_filter_0, 0), (self.wxgui_fftsink2_0, 0))
        self.connect((self.blocks_throttle_0, 0), (self.band_pass_filter_0, 0))

    def get_samp_rate_0(self):
        return self.samp_rate_0

    def set_samp_rate_0(self, samp_rate_0):
        self.samp_rate_0 = samp_rate_0
        self.wxgui_fftsink2_0.set_sample_rate(self.samp_rate_0)
        self.blocks_throttle_0.set_sample_rate(self.samp_rate_0)
        self.band_pass_filter_0.set_taps(firdes.band_pass(1, self.samp_rate_0, 4e3, 6e3, 2e2, firdes.WIN_HAMMING, 6.76))

    def get_f(self):
        return self.f

    def set_f(self, f):
        self.f = f
        self._f_slider.set_value(self.f)
        self._f_text_box.set_value(self.f)

    def get_b(self):
        return self.b

    def set_b(self, b):
        self.b = b
        self._b_slider.set_value(self.b)
        self._b_text_box.set_value(self.b)
    
    def printlen(self):
        print len(self.band_pass_filter_0.taps())


def main(top_block_cls=top_block, options=None):

    tb = top_block_cls()
    tb.printlen()
    tb.Start(True)
    tb.Wait()


if __name__ == '__main__':
    main()
